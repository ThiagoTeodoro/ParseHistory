# ParseHistory
Plugin created to store the parse performed in Dummys.

You can open the panel typing in the **say channel**:

/say Open ParseHistory

Or you can use the Command line option:

/Parse open\
/Parse close

For record parses you just need to for a Dummy and make parses the plugin will register data every time a parse 3mim ending.

**Installation Instructions**

Unzip the file in your folder:
C:\Users\[name of your user]\Documents\The Lord of the Rings Online\Plugins

And then you just need to open the LOTRO and load the plugin in the plugin manager.

ChangeLog
===============================================
v.0.0.1 = Beta version for test.\
v.0.0.2 = Add command line option.\
v.0.0.3 = Improving code structure.\
v.0.1.0 = Fix bug on reding decimal shifted pares, apply visualization like 200.5k insted 200,500.02 (This version will clean old pares to work properly)\
v.0.1.1 = Fix folders

Next plans
===============================================
- [x] Change the show number from 200,0123,111 for 200,01k
