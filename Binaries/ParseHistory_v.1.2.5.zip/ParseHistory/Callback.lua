------------------------------------------------------------------------------------------
-- Library file
-- Written by Teodoro [Thronur]
------------------------------------------------------------------------------------------

-- Call Back Function
function AddCallback(object, event, callback)
  if (object[event] == nil) then
    object[event] = callback;
  else
    if (type(object[event]) == "table") then
      table.insert(object[event], callback);
    else
      object[event] = {object[event], callback};
    end
  end
  return callback;
end

function RemoveCallback(object, event, callback)
  if (object[event] == callback) then
      object[event] = nil;
  else
      if (type(object[event]) == "table") then
        local size = table.getn(object[event]);
        for i = 1, size do
          if (object[event][i] == callback) then
            table.remove(object[event], i);
            break;
          end
        end
    end
  end
end