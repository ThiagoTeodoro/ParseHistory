------------------------------------------------------------------------------------------
-- Library file
-- Written by Teodoro [Thronur]
------------------------------------------------------------------------------------------

--Initialization of variables
PARSES = {};
MainWindow = nil;
ViewPortCaption = nil;
ViewPort = nil;
VScroll = nil;
BestParseValue = 0;
BestParseText = nil;