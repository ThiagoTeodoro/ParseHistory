------------------------------------------------------------------------------------------
-- Library file
-- Written by Teodoro [Thronur]
------------------------------------------------------------------------------------------

--Initialization of variables
DummyParseHistory = {};
WindowForDummys = nil;
ViewPortCaptionDummy = nil;
ViewPortDummy = nil;
VScrollDummy = nil;
BestParseValueOnDummy = 0;
BestParseText = nil;
ChatMonitor = Turbine.Chat;
PlayerMonitor = Turbine.Gameplay.LocalPlayer.GetInstance();